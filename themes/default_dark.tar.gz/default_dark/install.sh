#!/bin/bash
cp -rf far2l/* ~/.config/far2l
