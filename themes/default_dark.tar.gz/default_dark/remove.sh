#!/bin/bash
rm -rf ~/.config/far2l/plugins/colorer
rm -rf ~/.config/far2l/settings/colors.ini
rm -rf ~/.config/far2l/settings/farcolors.ini
rm -rf ~/.config/far2l/palette.ini
